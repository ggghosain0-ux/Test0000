const express = require('express');
const axios = require('axios');
const fs = require('fs');
const path = require('path');

const { db } = require('../function/db');
const { calculateResource } = require('../function/calculateResource');
const { ensureAuthenticated } = require('../function/ensureAuthenticated');
const { getRandomPort } = require('../function/getRandomPort');
const { getSkyport } = require('../function/getSkyport');

const router = express.Router();

// Existing resources (the ones in use on servers)
const existingResources = async (userID) => {
  return {
    "cpu": await calculateResource(userID, 'Cpu'),
    "ram": await calculateResource(userID, 'Memory'),
    "disk": await calculateResource(userID, 'Disk')
  };
};

// Max resources (the ones the user has purchased or been given)
const maxResources = async (email) => {
  return {
    "cpu": await db.get(`cpu-${email}`),
    "ram": await db.get(`ram-${email}`),
    "disk": await db.get(`disk-${email}`)
  };
};

// Delete server
router.get('/delete', ensureAuthenticated, async (req, res) => {
  if (!req.user || !req.user.email || !req.user.id) return res.redirect('/');
    if (!req.query.id) return res.redirect('../dashboard?err=MISSINGPARAMS');
    try {
        const skyport = await getSkyport();
        const userId = await db.get(`id-${req.user.email}`);
        const serverId = req.query.id;

        if (skyport.isStandalone) {
          const { getLocalServer, deleteLocalServer } = require('../function/localSkyport');
          const serverData = await getLocalServer(req.user.id, serverId);
          if (!serverData) return res.redirect('../dashboard?err=NOTFOUND');
          if (serverData.User !== userId) return res.redirect('../dashboard?err=DONOTOWN');
          await deleteLocalServer(req.user.id, serverId);
          return res.redirect('/dashboard?success=DELETE');
        }

        const server = await axios.post(`${skyport.url}/api/getInstance`, {
          id: serverId
        }, {
          headers: {
            'x-api-key': skyport.key
          }
        });
        console.log(server.data)

        if (server.data.User !== userId) return res.redirect('../dashboard?err=DONOTOWN');

        await axios.delete(`${skyport.url}/api/instance/delete`, {
          headers: {
            'x-api-key': skyport.key
          },
          data: {
            id: serverId
          }
        });

        res.redirect('/dashboard?success=DELETE');
    } catch (error) {
        if (error.response && error.response.status === 404) return res.redirect('../dashboard?err=NOTFOUND');
        
        console.error(error);
        res.redirect('../dashboard?err=INTERNALERROR');
    }
});

// Create server
router.get('/create', ensureAuthenticated, async (req, res) => {
  if (!req.user || !req.user.email || !req.user.id) return res.redirect('/');
  if (!req.query.name || !req.query.node || !req.query.image || !req.query.cpu || !req.query.ram) return res.redirect('../create-server?err=MISSINGPARAMS'); //  || !req.query.disk
  
  // Check if user has enough resources to create a server
  const skyport = await getSkyport();

  const max = await maxResources(req.user.email);
  const existing = await existingResources(req.user.id);

  if (parseInt(req.query.cpu) > parseInt(max.cpu - existing.cpu)) return res.redirect('../create-server?err=NOTENOUGHRESOURCES');
  if (parseInt(req.query.ram) > parseInt(max.ram - existing.ram)) return res.redirect('../create-server?err=NOTENOUGHRESOURCES');
  // if (parseInt(req.query.disk) > parseInt(max.disk - existing.disk)) return res.redirect('../create-server?err=NOTENOUGHRESOURCES');

  // Ensure resources are above 128MB / 0 core

  if (parseInt(req.query.ram) < 128) return res.redirect('../create-server?err=INVALID');
  if (parseInt(req.query.cpu) < 0) return res.redirect('../create-server?err=INVALID');
  // if (parseInt(req.query.disk) < 128) return res.redirect('../create-server?err=INVALID');

  // Name checks

  if (req.query.name.length > 100) return res.redirect('../create-server?err=INVALID');
  if (req.query.name.length < 3) return res.redirect('../create-server?err=INVALID');

  // Make sure node, image, resources are numbers
  if ( isNaN(req.query.cpu) || isNaN(req.query.ram)) return res.redirect('../create-server?err=INVALID'); // || isNaN(req.query.disk) || isNaN(req.query.node) || isNaN(req.query.image) ||
  if (req.query.cpu < 0 || req.query.ram < 1) return res.redirect('../create-server?err=INVALID'); // || req.query.disk < 1

  try {
      const userId = await db.get(`id-${req.user.email}`);
      const name = req.query.name;
      const nodeId = req.query.node;
      const imageId = req.query.image;
      const cpu = parseInt(req.query.cpu);
      const memory = parseInt(req.query.ram);
      // const disk = parseInt(req.query.disk); 

      const portsPath = path.join(__dirname, '../storage/ports.json');
      const portsData = JSON.parse(fs.readFileSync(portsPath, 'utf-8'));
      const selectedPortKey = getRandomPort(portsData.portAvailable);
      const selectedPort = portsData.portAvailable[selectedPortKey];

      if(!selectedPort || !selectedPortKey) {
        console.error('No ports available');
      }

      portsData.portInUse[selectedPortKey] = selectedPort;
      delete portsData.portAvailable[selectedPortKey];

      fs.writeFileSync(portsPath, JSON.stringify(portsData, null, 2), 'utf-8');

      const images = require('../storage/images.json');

      const image2 = images.find(image => image.Id === imageId);
      const imagename = image2.Name;
      if (!image2) return res.redirect('../create-server?err=INVALID_IMAGE');
      const image = image2.Image;

      if (skyport.isStandalone) {
        console.log("Deploying server in standalone local mode.");
        const { addLocalServer } = require('../function/localSkyport');
        await addLocalServer(req.user.id, name, cpu, memory, 1024, nodeId, imageId);
        return res.redirect('../dashboard?success=CREATED');
      }

      await axios.post(`${skyport.url}/api/instances/deploy`, {
          image,
          imagename,
          memory,
          cpu,
          ports: selectedPort,
          nodeId,
          name,
          user: userId,
          primary: selectedPort
      }, {
          headers: {
            'x-api-key': skyport.key
          }
      });

      res.redirect('../dashboard?success=CREATED');
  } catch (error) {
      console.error(error);
      res.redirect('../create-server?err=ERRORONCREATE');
  }
});

router.get('/create-server', ensureAuthenticated, async (req, res) => {
  if (!req.user || !req.user.email || !req.user.id) return res.redirect('/');
    res.render('create', {
      req: req, // Requests (queries) 
      name: process.env.APP_NAME, // Dashboard name
      user: req.user, // User info (if logged in)
      admin: await db.get(`admin-${req.user.email}`), // Admin status
      coins: await db.get(`coins-${req.user.email}`), // Coins
      images: require('../storage/images.json'), // Images data
      nodes: require('../storage/nodes.json') // Nodes data
    });
});

module.exports = router;
