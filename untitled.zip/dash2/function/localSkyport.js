const { db } = require('./db');
const randomstring = require('randomstring');

async function getLocalServers(userId) {
  const servers = await db.get(`local-servers-${userId}`) || [];
  return servers;
}

async function saveLocalServers(userId, servers) {
  await db.set(`local-servers-${userId}`, servers);
}

async function addLocalServer(userId, name, cpu, memory, disk, nodeId, imageId) {
  const servers = await getLocalServers(userId);
  const containerId = 'sp-' + randomstring.generate({ length: 8, charset: 'hex' });
  const newServer = {
    Name: name,
    ContainerId: containerId,
    Cpu: cpu / 100, // Skyport stores Cpu as a decimal fraction of a core (e.g. 0.50 = 50%)
    Memory: memory,
    Disk: disk || 1024,
    User: userId,
    NodeId: nodeId,
    ImageId: imageId,
    CreatedAt: new Date().toISOString()
  };
  servers.push(newServer);
  await saveLocalServers(userId, servers);
  return newServer;
}

async function deleteLocalServer(userId, containerId) {
  const servers = await getLocalServers(userId);
  const filtered = servers.filter(s => s.ContainerId !== containerId);
  await saveLocalServers(userId, filtered);
  return true;
}

async function getLocalServer(userId, containerId) {
  const servers = await getLocalServers(userId);
  return servers.find(s => s.ContainerId === containerId);
}

module.exports = {
  getLocalServers,
  addLocalServer,
  deleteLocalServer,
  getLocalServer
};
