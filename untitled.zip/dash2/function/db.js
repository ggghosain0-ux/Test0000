const path = require('path');
const Keyv = require('keyv');
const dbPath = path.join(__dirname, '../storage/database.sqlite');
const db = new Keyv(`sqlite://${dbPath}`);

module.exports = { db };