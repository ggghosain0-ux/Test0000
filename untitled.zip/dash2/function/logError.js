const fs = require('fs');
const path = require('path');

const logError = (message, error = '') => {
  const errorMessage = `[ERROR] ${message}${error ? `: ${error.message || error}` : ''}\n`;
  const logFile = process.env.LOGS_ERROR_PATH || path.join(__dirname, '../storage/logs/error.log');
  fs.appendFile(logFile, errorMessage, (err) => {
    if (err) console.error(`Failed to save log: ${err}`);
  });
  console.error(errorMessage);
};

module.exports = { logError };
